package controle;

import java.util.ArrayList;
import modelo.Banda;

/**
 *
 * @author odams
 */
public class bandaControle {

    private ArrayList<Banda> listaBandas = new ArrayList<>();

    public ArrayList<Banda> getListaDeBandas() {
        return listaBandas;
    }

    public void setListaDeBandas(ArrayList<Banda> ListaDeBandas) {
        this.listaBandas = ListaDeBandas;
    }

    public void cadastrarBandas() {
        System.out.println();
        System.out.println("...::: Cadastrar Banda :::...");
        System.out.println("--------------------------------");

        Banda banda = new Banda();
        banda.lerBandas();
        listaBandas.add(banda);
        
        System.out.println("----------------------------");
        System.out.println();
    }

    public void listarBandas() {
        System.out.println();
        System.out.println("...::: Listar Bandas :::...");
        System.out.println("----------------------------");

        for (int i = 0; i < listaBandas.size(); i++) {
            Banda banda = listaBandas.get(i);
            banda.listarBandas();
        }
        
        if(listaBandas.isEmpty()){
            System.out.println();
            System.out.println("nao existe bandas para listar :(");
            System.out.println();
        }
        
        System.out.println("----------------------------");
        System.out.println();
    }

    public void visualizarBandas() {
        System.out.println();
        System.out.println("...::: Visualizar Bandas :::...");
        System.out.println("----------------------------");

        for (int i = 0; i < listaBandas.size(); i++) {
            Banda banda = listaBandas.get(i);
            banda.visualizarBandas();
        }
        
        if(listaBandas.isEmpty()){
            
            System.out.println();
            System.out.println("Nao existe bandas para visualizar :(");
            System.out.println();
        }

        System.out.println("----------------------------");
        System.out.println();
    }
    
    public void editarBandas() {
        System.out.println();
        System.out.println("...::: Editar Banda :::...");
        System.out.println("----------------------------");

        for (int i = 0; i < listaBandas.size(); i++) {
            Banda banda = listaBandas.get(i);
            banda.editarBandas();
        }
        
        if(listaBandas.isEmpty()){
            System.out.println();
            System.out.println("Nao existe bandas para editar :(");
            System.out.println();
        }

        System.out.println("----------------------------");
        System.out.println();
    }
    
    public void removerBandas() {
        System.out.println();
        System.out.println("...::: Remover Banda :::...");
        System.out.println("----------------------------");
        
        for (int i = 0; i < listaBandas.size(); i++) {
            Banda nomeBanda = listaBandas.remove(i);
            System.out.println();
            System.out.println("Banda removida");
            System.out.println();
        }
        
        if (listaBandas.isEmpty()){
            
            System.out.println();
            System.out.println("Nao possui mais bandas para remover");
            System.out.println();
        }

        System.out.println("----------------------------");
        System.out.println();
    }
    
    public void ordenarBandas() {
        System.out.println();
        System.out.println("...::: Ordenar Bandas :::...");
        System.out.println("----------------------------");

        for (int i = 0; i < listaBandas.size(); i++) {
            Banda banda = listaBandas.get(i);
            banda.ordenarBandas();
        }
        
        if(listaBandas.isEmpty()){
            
            System.out.println();
            System.out.println("Nao existe bandas para ordenar :(");
            System.out.println();
        }

        System.out.println("----------------------------");
        System.out.println();
    }
    
    public void pesquisarBandas() {
        System.out.println();
        System.out.println("...::: Pesuisar Banda :::...");
        System.out.println("----------------------------");

        for (int i = 0; i < listaBandas.size(); i++) {
            Banda banda = listaBandas.get(i);
            banda.pesquisarBandas();
        }
        
        if(listaBandas.isEmpty()){
            System.out.println();
            System.out.println("Nao existe bandas para pesquisar :(");
            System.out.println();
        }

        System.out.println("----------------------------");
        System.out.println();
    }
    
}
