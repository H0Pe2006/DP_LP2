/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.Scanner;

/**
 *
 * @author aluno
 */
public class Banda {
    
    private int idBanda;
    private String nomeBanda;
    private int numDiscos;
    private String estilo;
    private final Scanner LER = new Scanner(System.in);

    public Banda(int idNome, String nomeBanda, int numDiscos, String estilo) {
        this.idBanda = idNome;
        this.nomeBanda = nomeBanda;
        this.numDiscos = numDiscos;
        this.estilo = estilo;
    }
    
    public Banda(){
        
    }

    public int getIdBanda() {
        return idBanda;
    }

    public void setIdBanda(int idBanda) {
        this.idBanda = idBanda;
    }

    public String getNomeBanda() {
        return nomeBanda;
    }

    public void setNomeBanda(String nomeBanda) {
        this.nomeBanda = nomeBanda;
    }

    public int getNumDiscos() {
        return numDiscos;
    }

    public void setNumDiscos(int numDiscos) {
        this.numDiscos = numDiscos;
    }

    public String getEstilo() {
        return estilo;
    }

    public void setEstilo(String estilo) {
        this.estilo = estilo;
    }
    
    
    @Override
    public String toString() {
        return "Id da Banda: " + idBanda + ", Nome da Banda: " + nomeBanda + ", Numero de Discos: " + numDiscos + ", Estilo: " + estilo;
    }
    
    public void lerBandas() {
        Scanner ler = new Scanner(System.in);

        System.out.print("Id da Banda: ");
        this.setIdBanda(ler.nextInt());
        
        System.out.print("Nome da Banda: ");
        this.setNomeBanda(ler.next());

        System.out.print("Numero de discos da banda: ");
        this.setNumDiscos(ler.nextInt());
        
        System.out.print("Estilo da Banda: ");
        this.setEstilo(ler.next());

    }

    public void visualizarBandas() {
        System.out.println("Id da banda: " + this.getIdBanda());
        System.out.println("Nome da banda: " + this.getNomeBanda());
        System.out.println("Numero de discos da banda: " + this.getNumDiscos());
        System.out.println("Estilo da banda: " + this.getEstilo());

        System.out.println();
    }

    public void listarBandas() {
        
        System.out.println("Nome da banda: " + this.getNomeBanda());
        System.out.println("Numero de discos da banda: "+this.getNumDiscos());
        System.out.println("Estilo da banda: " + this.getEstilo());

        System.out.println();
    }
    
    public void editarBandas() {
        
        System.out.println("Mudar id da banda: " + this.getIdBanda());
        System.out.println("Mudar nome da banda: " + this.getNomeBanda());
        System.out.println("Mudar numero de discos da banda: "+this.getNumDiscos());
        System.out.println("Mudar estilo da banda: " + this.getEstilo());

        System.out.println();
    } 
    
    public void pesquisarBandas() {
        
        System.out.println("Digite o Id da banda: ");
        int id = LER.nextInt();
        
//        for(int i = 0; i< listaBandas.lenght;)
        
    }  
    
    public void removerBandas() {
        System.out.println("Bandas removidas");
    }  
    
    public void ordenarBandas() {
        
        System.out.println("Id da banda: " + this.getIdBanda());

        System.out.println();
    }  
    
    public void sair() {

        System.out.println();
    }  
}
