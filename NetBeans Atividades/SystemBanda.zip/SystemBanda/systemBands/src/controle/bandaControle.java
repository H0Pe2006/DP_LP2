package controle;

import java.util.ArrayList;
import java.util.Scanner;
import modelo.Banda;

/**
 *
 * @author odams
 */
public class bandaControle {
    
    private final Scanner LER = new Scanner(System.in);
    private ArrayList<Banda> listaBandas = new ArrayList<>();
    private Banda bandaEncontrada = null;
    boolean existe = false;

    public ArrayList<Banda> getListaDeBandas() {
        return listaBandas;
    }

    public void cadastrarBandas() {
        System.out.println();
        System.out.println("...::: Cadastrar Banda :::...");
        System.out.println("--------------------------------");
        
        Scanner ler = new Scanner(System.in);
        
        Banda banda = new Banda();

        System.out.print("Id da Banda: ");
        banda.setIdBanda(ler.nextInt());
        
        System.out.print("Nome da Banda: ");
        banda.setNomeBanda(ler.next());

        System.out.print("Numero de discos da banda: ");
        banda.setNumDiscos(ler.nextInt());
        
        System.out.print("Estilo da Banda: ");
        banda.setEstilo(ler.next());
        
        listaBandas.add(banda);
        
        System.out.println("----------------------------");
        System.out.println();
    }

    public void listarBandas() {
        System.out.println();
        System.out.println("...::: Listar Bandas :::...");
        System.out.println("----------------------------");

        for(int i = 0; i < listaBandas.size(); i++){
            Banda banda = listaBandas.get(i);
            System.out.println("Nome: "+banda.getNomeBanda());
            System.out.println("Num Discos: "+banda.getNumDiscos());
            System.out.println("--------------");
        }
        
           
        System.out.println("----------------------------");
        System.out.println();
    }

//    public void visualizarBandas() {
//        System.out.println();
//        System.out.println("...::: Visualizar Bandas :::...");
//        System.out.println("----------------------------");

//        for (int i = 0; i < listaBandas.size(); i++) {
//            Banda banda = listaBandas.get(i);
//            banda.visualizarBandas();
//        }
        
//        if(listaBandas.isEmpty()){
//            
//            System.out.println();
//            System.out.println("Nao existe bandas para visualizar :(");
//            System.out.println();
//        }
//
//        System.out.println("----------------------------");
//        System.out.println();
//    }
//    
//    public void editarBandas() {
//        System.out.println();
//        System.out.println("...::: Editar Banda :::...");
//        System.out.println("----------------------------");
//
//        for (int i = 0; i < listaBandas.size(); i++) {
//            Banda banda = listaBandas.get(i);
//            banda.editarBandas();
//        }
//        
//        if(listaBandas.isEmpty()){
//            System.out.println();
//            System.out.println("Nao existe bandas para editar :(");
//            System.out.println();
//        }
//
//        System.out.println("----------------------------");
//        System.out.println();
//    }
//    
    public void removerBandas() {
        System.out.println();
        System.out.println("...::: Remover Banda :::...");
        System.out.println("----------------------------");
        
        System.out.println("Banda removida");
        
        if (bandaEncontrada != null){
            int index = listaBandas.indexOf(bandaEncontrada);
            listaBandas.remove(index);
            bandaEncontrada = null;
        }

        System.out.println("----------------------------");
        System.out.println();
    }
    
//    public void ordenarBandas() {
//        System.out.println();
//        System.out.println("...::: Ordenar Bandas :::...");
//        System.out.println("----------------------------");
//        
//         System.out.println("Id da banda: " + banda.getIdBanda());
//
//         System.out.println();

//        for (int i = 0; i < listaBandas.size(); i++) {
//            Banda banda = listaBandas.get(i);
//            banda.ordenarBandas();
//        }
        
//        if(listaBandas.isEmpty()){
//            
//            System.out.println();
//            System.out.println("Nao existe bandas para ordenar :(");
//            System.out.println();
//        }
//
//        System.out.println("----------------------------");
//        System.out.println();
//    }
    
    public void pesquisarBandas() {
        System.out.println();
        System.out.println("...::: Pesquisar Banda :::...");
        System.out.println("----------------------------");
        
        System.out.println("Digite o id da banda: ");
        int id = LER.nextInt();
        
        for(int i = 0; i < listaBandas.size(); i++) {
            Banda banda = listaBandas.get(i);
            if(id == banda.getIdBanda()) {
                System.out.println(banda);
                bandaEncontrada = banda;
            }
        }
        
        for(int i = 0; i < listaBandas.size(); i++){
            Banda banda = listaBandas.get(i);
            if(id == banda.getIdBanda()){
               existe = true;
            }{
                System.out.println("Essa banda não existe :(");  
            }

        System.out.println("----------------------------");
        System.out.println();
        
        }
    }
    
//    public void lerBandas() {
//        Scanner ler = new Scanner(System.in);
//
//        System.out.print("Id da Banda: ");
//        banda.setIdBanda(ler.nextInt());
//        
//        System.out.print("Nome da Banda: ");
//        banda.setNomeBanda(ler.next());
//
//        System.out.print("Numero de discos da banda: ");
//        banda.setNumDiscos(ler.nextInt());
//        
//        System.out.print("Estilo da Banda: ");
//        banda.setEstilo(ler.next());
//
//    }
//
//    public void visualizarBandas() {
//        System.out.println("Id da banda: " + banda.getIdBanda());
//        System.out.println("Nome da banda: " + banda.getNomeBanda());
//        System.out.println("Numero de discos da banda: " + banda.getNumDiscos());
//        System.out.println("Estilo da banda: " + banda.getEstilo());
//
//        System.out.println();
//    }
//
//    public void listarBandas() {
//        
//        System.out.println("Nome da banda: " + banda.getNomeBanda());
//        System.out.println("Numero de discos da banda: "+banda.getNumDiscos());
//        System.out.println("Estilo da banda: " + banda.getEstilo());
//
//        System.out.println();
//    }
//    
//    public void editarBandas() {
//        
//        System.out.println("Mudar id da banda: " + banda.getIdBanda());
//        System.out.println("Mudar nome da banda: " + banda.getNomeBanda());
//        System.out.println("Mudar numero de discos da banda: "+banda.getNumDiscos());
//        System.out.println("Mudar estilo da banda: " + banda.getEstilo());
//
//        System.out.println();
//    } 
//    
//    public void pesquisarBandas() {
//        
//        System.out.println("Digite o Id da banda: ");
//        int id = LER.nextInt();
//        
//        for(int i = 0; i< listaBandas.lenght;)
//        
//    }  

    public void sair() {

        System.out.println();
    }  
    
}
