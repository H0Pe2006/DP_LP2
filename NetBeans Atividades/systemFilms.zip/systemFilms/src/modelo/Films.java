package modelo;
import java.util.Scanner;

public class Films {

    private int idFilm;
    private String nomeFilm;
    private String generoFilm;
    private String dataLancaFilm;
    private int duracaoFilm;

    //construtor de inicialização
    public Films(int idFilm, String nomeFilm, String generoFilm, String dataLancaFilm, int duracaoFilm) {
        this.idFilm = idFilm;
        this.nomeFilm = nomeFilm;
        this.generoFilm = generoFilm;
        this.dataLancaFilm = dataLancaFilm;
        this.duracaoFilm = duracaoFilm;
    }

    //construtor padrão
    public Films() {
    }

    //getters
    public int getIdFilm() {
        return idFilm;
    }

    public String getNomeFilm() {
        return nomeFilm;
    }

    public String getGeneroFilm() {
        return generoFilm;
    }

    public String getDataLancaFilm() {
        return dataLancaFilm;
    }

    public int getDuracaoFilm() {
        return duracaoFilm;
    }

    //setters
    public void setIdFilm(int idFilm) {
        this.idFilm = idFilm;
    }

    public void setNomeFilm(String nomeFilm) {
        this.nomeFilm = nomeFilm;
    }

    public void setGeneroFilm(String generoFilm) {
        this.generoFilm = generoFilm;
    }

    public void setDataLancaFilm(String dataLancaFilm) {
        this.dataLancaFilm = dataLancaFilm;
    }

    public void setDuracaoFilm(int duracaoFilm) {
        this.duracaoFilm = duracaoFilm;
    }

    @Override
    public String toString() {
        return "Films{" + "idFilm=" + idFilm + ", nomeFilm=" + nomeFilm + ", generoFilm=" + generoFilm + ", dataLancaFilm=" + dataLancaFilm + ", duracaoFilm=" + duracaoFilm + '}';
    }

    public void lerFilm() {
        Scanner ler = new Scanner(System.in);

        System.out.print("Id do filme:");
        this.setIdFilm(ler.nextInt());

        System.out.print("Nome do filme:");
        this.setNomeFilm(ler.next());

        System.out.print("Gênero do filme:");
        this.setGeneroFilm(ler.next());

        System.out.print("Data de lançamento:");
        this.setDataLancaFilm(ler.next());

        System.out.print("Tempo de duração (min):");
        this.setDuracaoFilm(ler.nextInt());

    }

    public void visualizarFilm() {
        System.out.println("Id do filme:" + this.getIdFilm());
        System.out.println("Nome do filme:" + this.getNomeFilm());
        System.out.println("Genero do filme:" + this.getGeneroFilm());
        System.out.println("Data de lançamento:" + this.getDataLancaFilm());
        System.out.println("Tempo de duração (min):" + this.getDuracaoFilm());

        System.out.println();
    }

    public void listarFilm() {

        System.out.println("Nome do filme:" + this.getNomeFilm());
        System.out.println("Genero do filme:" + this.getGeneroFilm());

        System.out.println();
    }
}
