package controle;
import java.util.ArrayList;
import java.util.Scanner;
import modelo.Films;

public class FilmControle {
    private ArrayList<Films> listaFilms = new ArrayList<>();

    public ArrayList<Films> getListaFilms() {
        return listaFilms;
    }

    public void setListaFilms(ArrayList<Films> listaFilms) {
        this.listaFilms = listaFilms;
    }
    //////////////////////////////////////////////////////////////////
    public void cadastrarFilms() {
        System.out.println("...::: Cadastrar Filmes :::...");
        System.out.println("-------------------------------");

        Films film = new Films();
        film.lerFilm();
        listaFilms.add(film);

        System.out.println("-------------------------------");
    }
    /////////////////////////////////////////////////////////////////
    public void removerFilms(){
        System.out.println("...::: Remover Filmes :::...");
        System.out.println("----------------------------");
        
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o nome do filme que deseja remover: ");
        String nomeFilm = scanner.nextLine();
        
        boolean filmeEncontrado = false;
        Films filmeRemovido = null;

        for (Films filme : listaFilms) {
            if (filme.getNomeFilm().equalsIgnoreCase(nomeFilm)) {
                filmeRemovido = filme;
                filmeEncontrado = true;
                break;
            }
        }
        
        if (filmeEncontrado) {
            listaFilms.remove(filmeRemovido);
            System.out.println("Filme removido com sucesso!");
        } else {
            System.out.println("Filme não encontrado.");
        }
        
        System.out.println("----------------------------");
    }
    /////////////////////////////////////////////////////////////////
    public void listarFilms() {
        System.out.println("...::: Listar Filmes :::...");
        System.out.println("---------------------------");

        for (int i = 0; i < listaFilms.size(); i++) {
            Films film = listaFilms.get(i);
            film.listarFilm();
        }

        System.out.println("----------------------------");
    }
    /////////////////////////////////////////////////////////////////
    public void visualizarFilms() {
        System.out.println("...::: Visualizar Filmes :::...");
        System.out.println("-------------------------------");

        for (int i = 0; i < listaFilms.size(); i++) {
            Films film = listaFilms.get(i);
            film.visualizarFilm();
        }

        System.out.println("----------------------------");
    }
    //////////////////////////////////////////////////////////////////
    public void pesquisarFilms() {
        System.out.println("...::: Pesquisar Filmes :::...");
        System.out.println("----------------------------");

        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o nome do filme que deseja pesquisar: ");
        String nomeFilm = scanner.nextLine();

        boolean filmeEncontrado = false;

        for (Films filme : listaFilms) {
            if (filme.getNomeFilm().equalsIgnoreCase(nomeFilm)) {
                filmeEncontrado = true;
                break;
            }
        }

        if (filmeEncontrado) {
            visualizarFilms();
        } else {
            System.out.println("Filme não encontrado.");
        }

        System.out.println("----------------------------");
    }
    //////////////////////////////////////////////////////////////////
    public void editarFilms(){
        
    }
}
