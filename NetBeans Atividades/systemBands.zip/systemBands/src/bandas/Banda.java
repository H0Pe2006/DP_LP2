/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bandas;

/**
 *
 * @author aluno
 */
public class Banda {
    
    private int idBanda;
    private String nomeBanda;
    private String nomeIntegrantes;
    private int idadeIntegrantes;
    private char sexoIntegrantes;
    private String instrumentoIntegrantes;
    private String estilo;

    public Banda(int idNome, String nomeBanda, String nomeIntegrantes, int idadeIntegrantes, char sexoIntegrantes, String instrumentoIntegrantes, String estilo) {
        this.idBanda = idNome;
        this.nomeBanda = nomeBanda;
        this.nomeIntegrantes = nomeIntegrantes;
        this.idadeIntegrantes = idadeIntegrantes;
        this.sexoIntegrantes = sexoIntegrantes;
        this.instrumentoIntegrantes = instrumentoIntegrantes;
        this.estilo = estilo;
    }
    
    public Banda(){
        
    }

    public int getIdBanda() {
        return idBanda;
    }

    public void setIdBanda(int idBanda) {
        this.idBanda = idBanda;
    }

    public String getNomeBanda() {
        return nomeBanda;
    }

    public void setNomeBanda(String nomeBanda) {
        this.nomeBanda = nomeBanda;
    }

    public String getNomeIntegrantes() {
        return nomeIntegrantes;
    }

    public void setNomeIntegrantes(String nomeIntegrantes) {
        this.nomeIntegrantes = nomeIntegrantes;
    }

    public int getIdadeIntegrantes() {
        return idadeIntegrantes;
    }

    public void setIdadeIntegrantes(int idadeIntegrantes) {
        this.idadeIntegrantes = idadeIntegrantes;
    }

    public char getSexoIntegrantes() {
        return sexoIntegrantes;
    }

    public void setSexoIntegrantes(char sexoIntegrantes) {
        this.sexoIntegrantes = sexoIntegrantes;
    }

    public String getInstrumentoIntegrantes() {
        return instrumentoIntegrantes;
    }

    public void setInstrumentoIntegrantes(String instrumentoIntegrantes) {
        this.instrumentoIntegrantes = instrumentoIntegrantes;
    }

    public String getEstilo() {
        return estilo;
    }

    public void setEstilo(String estilo) {
        this.estilo = estilo;
    }
    
    
    @Override
    public String toString() {
        return "Banda{" + "idNome=" + idBanda + ", nomeBanda=" + nomeBanda + ", nomeIntegrantes=" + nomeIntegrantes + ", idadeIntegrantes=" + idadeIntegrantes + ", sexoIntegrantes=" + sexoIntegrantes + ", instrumentoIntegrantes=" + instrumentoIntegrantes + ", estilo=" + estilo + '}';
    }
    
}
