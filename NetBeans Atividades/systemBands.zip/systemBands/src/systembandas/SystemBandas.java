/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package systembandas;

import bandas.Banda;
import java.util.Scanner;

/**
 *
 * @author aluno
 */
public class SystemBandas {

    final static Scanner LER = new Scanner(System.in);
    public static void main(String[] args) {
        
        Banda banda1 = new Banda();
        
        banda1 = lerBanda(banda1);
        
        System.out.println(banda1.toString());
    }
    
    public static Banda lerBanda(Banda b1){
        
        System.out.println("ID da banda: ");
        b1.setIdBanda(LER.nextInt());
        
        System.out.println("Nome da banda: ");
        b1.setNomeBanda(LER.next());
        
        System.out.println("Estilo da banda: ");
        b1.setEstilo(LER.next());
        
        System.out.println("Nome do integrante: ");
        b1.setNomeIntegrantes(LER.next());
        
        System.out.println("Idade do integrante");
        b1.setIdadeIntegrantes(LER.nextInt());
        
        System.out.println("Sexo do Integrante: ");
        b1.setSexoIntegrantes(LER.next().charAt(0));  
        
        System.out.println("Instrumento do integrante: ");
        b1.setInstrumentoIntegrantes(LER.next());
        
        return  b1;
    }
}