package visao;

import controle.bandaControle;
import java.util.Scanner;

public class SystemBanda {

    public static void main(String[] args) {
        int op;

        bandaControle banda = new bandaControle();

        while (true) {

            op = imprimirMenu();

            if (op == 0) {
                System.out.println("Valeu por usar Nosso 'BandApp'");
                break;
            }
            
            switch (op) {
                case 1:
                    banda.cadastrarBandas();
                    break;
                    
                case 2:
                    banda.editarBandas();
                    break;
                    
                case 3:
                    banda.removerBandas();
                    break;
                           
                case 4:
                    banda.listarBandas();
                    break;

                case 5:
                    banda.visualizarBandas();
                    break;
                    
                case 6:
                    banda.ordenarBandas();
                    break;
                    
                case 7:
                    banda.pesquisarBandas();
                    break;
            }
        }
    }

    public static int imprimirMenu() {
        int op = -1;

        Scanner ler = new Scanner(System.in);

        System.out.println("...::: Menu - BandApp :::...");
        System.out.println();
        System.out.println(""
                + "\t1) Cadastrar Banda\n"
                + "\t2) Editar Banda\n"
                + "\t3) Remover Banda\n"
                + "\t4) Listar Bandas\n"
                + "\t5) Visualizar Bandas\n"
                + "\t6) Ordenar Bandas\n"
                + "\t7) Pesquisar Banda\n"
                + "\t0) Sair");
        System.out.print("--> ");

        op = ler.nextInt();

        return op;
    }
}
