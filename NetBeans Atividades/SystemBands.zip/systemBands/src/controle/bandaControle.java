package controle;

import java.util.ArrayList;
import modelo.Banda;

/**
 *
 * @author odams
 */
public class bandaControle {

    private ArrayList<Banda> listaBandas = new ArrayList<>();

    public ArrayList<Banda> getListaDeBandas() {
        return listaBandas;
    }

    public void setListaDeBandas(ArrayList<Banda> ListaDeBandas) {
        this.listaBandas = ListaDeBandas;
    }

    public void cadastrarBandas() {
        System.out.println();
        System.out.println("...::: Cadastrar Banda :::...");
        System.out.println("--------------------------------");

        Banda banda = new Banda();
        banda.lerBandas();
        listaBandas.add(banda);
        
        System.out.println("----------------------------");
        System.out.println();
    }

    public void listarBandas() {
        System.out.println();
        System.out.println("...::: Listar Bandas :::...");
        System.out.println("----------------------------");

        for (int i = 0; i < listaBandas.size(); i++) {
            Banda banda = listaBandas.get(i);
            banda.listarBandas();
        }

        System.out.println("----------------------------");
        System.out.println();
    }

    public void visualizarBandas() {
        System.out.println();
        System.out.println("...::: Visualizar Bandas :::...");
        System.out.println("----------------------------");

        for (int i = 0; i < listaBandas.size(); i++) {
            Banda banda = listaBandas.get(i);
            banda.visualizarBandas();
        }

        System.out.println("----------------------------");
        System.out.println();
    }
    
    public void editarBandas() {
        System.out.println();
        System.out.println("...::: Editar Banda :::...");
        System.out.println("----------------------------");

        for (int i = 0; i < listaBandas.size(); i++) {
            Banda banda = listaBandas.get(i);
            banda.editarBandas();
        }

        System.out.println("----------------------------");
        System.out.println();
    }
    
    public void removerBandas() {
        System.out.println();
        System.out.println("...::: Remover Banda :::...");
        System.out.println("----------------------------");

        for (int i = 0; i < listaBandas.size(); i++) {
            Banda banda = listaBandas.get(i);
            banda.removerBandas();
        }

        System.out.println("----------------------------");
        System.out.println();
    }
    
    public void ordenarBandas() {
        System.out.println();
        System.out.println("...::: Ordenar Bandas :::...");
        System.out.println("----------------------------");

        for (int i = 0; i < listaBandas.size(); i++) {
            Banda banda = listaBandas.get(i);
            banda.ordenarBandas();
        }

        System.out.println("----------------------------");
        System.out.println();
    }
    
    public void pesquisarBandas() {
        System.out.println();
        System.out.println("...::: Pesuisar Banda :::...");
        System.out.println("----------------------------");

        for (int i = 0; i < listaBandas.size(); i++) {
            Banda banda = listaBandas.get(i);
            banda.pesquisarBandas();
        }

        System.out.println("----------------------------");
        System.out.println();
    }
}
